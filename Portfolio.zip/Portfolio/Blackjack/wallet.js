class Wallet{
    constructor(money){
    this.money;
    }
}