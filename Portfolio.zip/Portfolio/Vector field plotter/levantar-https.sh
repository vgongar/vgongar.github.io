http-server -S -C server.cert -K server.key -p 8080

